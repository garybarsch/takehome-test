#
# Problem:
# Given a list of integers, return a new sorted list without duplicate values.
# Return the answer in ascending sorted order.
#
# TODO: implement remove_duplicates1() and remove_duplicates2()
#


def remove_duplicates1(*, items: list[int]) -> list[int]:
    """
    Args:
        items (list[int]): A list of integers to remove duplicates from.

    Returns:
        list[int]: A sorted list of unique integers.
    """
    # TODO: add your code here
    return []


def remove_duplicates2(*, items: list[int]) -> list[int]:
    """
    Alternative to remove_duplicates1().

    Args:
        items (list[int]): A list of integers to remove duplicates from.

    Returns:
        list[int]: A sorted list of unique integers.
    """
    # TODO: add your code here
    return []
